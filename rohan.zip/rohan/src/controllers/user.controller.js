const db = require("../../config/connection");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = db.User;
const OverlayText = db.overlayText;
const sdk = require("api")("@leonardoai/v1.0#2qtdfpqlt40u8hs");

async function register(req, res) {
  try {
    const { username, password, email } = req.body;

    const isEmptykey = Object.keys(req.body).some((key) => {
      const value = req.body[key];
      return value === "" || value === null || value === undefined;
    });
    if (isEmptykey) {
      return res.status(400).json({ error: "please do not give empty fileds" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      username: username,
      email: email,
      password: hashedPassword,
    });

    return res.status(200).json({
      status: true,
      message: "User registered successfully",
      data: user,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      status: false,
      message: "Internal Server Error",
    });
  }
}

async function login(req, res) {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email: email } });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    const token = jwt.sign({ UserId: user.id }, "secretkey", {
      expiresIn: "1h",
    });
    return res
      .status(200)
      .json({ status: true, message: "Login successful", token });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ status: false, message: "Internal Server Error" });
  }
}

const generateImages = async (req, res) => {
  try {
    // leonardo AI image generation
    sdk
      .createGeneration({
        height: 512,
        modelId: "6bef9f1b-29cb-40c7-b9df-32b51c1f67d3",
        prompt: "An oil painting of a cat",
        width: 512,
      })
      .then(({ data }) => console.log(data))
      .catch((err) => console.error(err));
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ status: false, message: "Internal Server Error" });
  }
};

const setOverlayText = async (req, res) => {
  try {
    const { text } = req.body;
    await OverlayText.create({ text });
    return res
      .status(200)
      .json({ status: true, message: "Overlay text set successfully" });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ status: false, message: "Internal Server Error" });
  }
};

module.exports = { register, login, generateImages, setOverlayText };
