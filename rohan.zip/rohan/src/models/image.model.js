module.exports = (sequelize, DataTypes) => {
    const image = sequelize.define("image", {
        url: {
            type: DataTypes.STRING,
            allowNull: false
          },
        //   userId: {
        //     type: DataTypes.INTEGER,
        //     allowNull: false
        //   }
    });
    return image;
};
